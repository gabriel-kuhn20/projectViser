import {ModeloCliente} from "../componentes_pessoas/ModeloCliente";

export class ModeloEntrega {
    entregaId: number;
    cliente: ModeloCliente;
    criadoEm?: Date;
    dataEntrega: Date;

    constructor(entregaId: number, cliente: ModeloCliente,dataEntrega: Date = new Date(), criadoEm?: Date) {
        this.entregaId = entregaId;
        this.cliente = cliente;
        this.criadoEm = criadoEm;
        this.dataEntrega = dataEntrega;
    }
}